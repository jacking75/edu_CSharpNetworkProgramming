﻿
namespace Sodao.FastSocket.Server.Messaging
{
    /// <summary>
    /// message interface
    /// </summary>
    public interface IMessage
    {
    }
}